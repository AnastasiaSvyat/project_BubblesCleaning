import React from 'react'



function BubbleCleaning(){
  
    return(
        <div>
            <div className='secondLogoimg slideUp'><img src="https://www.flaticon.com/svg/static/icons/svg/1326/1326001.svg" alt=""/></div>
            <div className='sliderText nameCompany slideUp'>BuBBles Cleaning</div>
        </div>
    )
}
export default BubbleCleaning