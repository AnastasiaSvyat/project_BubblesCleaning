import React from 'react'
import Header from '../Header/header'


function ShopNav(){
    return(
        <div>
            <Header/>
        </div>
    )
}

export default ShopNav