import React from 'react'
import classes from '../../Styles/wave.module.css'


function SecondWave (){
    return(
             <div className = {classes.wave}>
                <img src="https://www.arredi.com.tr/site/o/72678/2016/10/bfe60e5b48fbdc91476ca7b5afc606ae.png?586434" alt=""/>
            </div>
            
    )
}

export default SecondWave