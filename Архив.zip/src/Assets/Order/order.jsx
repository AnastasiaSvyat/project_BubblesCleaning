import React from 'react'

function OrderNavImg(){
return(
    <div className='orderIcon'>
            <img  src="https://www.flaticon.com/svg/static/icons/svg/833/833400.svg" alt="icon"/>
    </div>
)
}

export default OrderNavImg