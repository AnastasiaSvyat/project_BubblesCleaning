import React from 'react'
import classes from '../../Styles/wave.module.css'



function Wave(){
return(
    <div className={classes.container}>
        <img src="http://carpetserv.ancorathemes.com/wp-content/uploads/2017/02/wave_17.png" alt=''/>
    </div>
    )
}

export default Wave