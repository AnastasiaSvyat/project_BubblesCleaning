import React from 'react'
import classes from '../../Styles/wave.module.css'



function ThirdWave(){
    return(
        <div className = {classes.wavethird}>
                <img src="https://static.tildacdn.com/tild3766-3264-4239-a233-613231343863/wave.png" alt=""/>

                </div>
    )
}

export default ThirdWave